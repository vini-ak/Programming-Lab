class Grafo:
	def __init__(self, vertices, inicio, fim):
		self._vertices = vertices # um dicionário com vértices e pesos.
		self._arestas = {}	# Dicionário contendo arestas e distâncias.
		self.inicio = inicio	# Definindo o inicio da pesquisa.
		self.fim = fim	# Definindo a cidade de destino.

	def addAresta(cls, a, b, distancia):
		''' Aresta e distância entre os vértices. '''
		cls._arestas[(a,b)] = distancia

	def getVertices(cls):
		''' Retorna os vértices. '''
		return cls._vertices

	def predecessor(cls, predecessor = None):
		''' O peso do predecessor. '''
		return predecessor

	def getArestas(cls):
		''' Retorna as arestas.'''
		return cls._arestas

	def get_lista_adjacencia_vertice(cls, vertice):
		return cls.getVertices()[vertice]['lista_adjacencia']

	def get_peso_vertice(cls, vertice):
		return cls.getVertices()[vertice]['peso']

	def set_peso_vertice(cls, vertice, novo_peso):
		''' Alterando o peso de um vértice. '''
		if cls.get_peso_vertice(vertice) == None:
			cls.getVertices()[vertice]['peso'] = novo_peso
		elif cls.get_peso_vertice(vertice) > novo_peso:
			cls.getVertices()[vertice]['peso'] = novo_peso
		else:
			cls.getVertices()[vertice]['peso'] += novo_peso

	def dijkstra(cls, pesquisa, menor_caminho=0):
		''' Procurando o menor caminho entre duas cidades. '''

		# Procurando a lista de adjacencia da cidade de partida
		lista_adjacencia = cls.get_lista_adjacencia_vertice(pesquisa)

		print(pesquisa)

		for vertice in lista_adjacencia:
			# Pegando o peso do predecessor...
			predecessor = cls.get_peso_vertice(pesquisa)
			# Definindo a distancia no peso...
			distancia = cls.getArestas()[(pesquisa, vertice)]

			# O peso do vértice é dado pelo peso do seu predecessor somado com a distância entre eles.
			peso = predecessor + distancia

			# Se ainda não houver um peso associado ao vértice ou
			# se o peso encontrado acima for menor do que o peso já
			# definido, o peso deste vértice será alterado.
			if cls.get_peso_vertice(vertice) == None:
				cls.set_peso_vertice(vertice, peso)

			elif peso < cls.get_peso_vertice(vertice):
				cls.set_peso_vertice(vertice, peso)

			if vertice == cls.fim:
				if (cls.get_peso_vertice(pesquisa) < menor_caminho) or menor_caminho == 0:
					menor_caminho = cls.get_peso_vertice(vertice)
					return menor_caminho

			else:
				menor_caminho = cls.dijkstra(vertice, menor_caminho)

		return menor_caminho

	def __str__(cls):
		''' Printa a lista de vértices e arestas. '''
		return str(cls.getVertices()) + '\n' + str(cls.getArestas())


# =============================================================== #

n, q, a, b = map(int, input().split())
# n é o número de vértices
# q é o número de arestas
# a é a cidade de inicio
# b é a cidade de destino

# Adicionando os vértices e definindo o peso e a lista de adjacência para cada um...
vertices = {}

for i in range(1, n+1):
	# Se o vértice é o ponto inicial para a pesquisa, seu peso é 0.
	# Senão, o algoritmo de Dijkstra diz que é infinity, mas vou usar None.
	vertices[i] = {}

	if i == a:
		# O vértice tem peso e lista de adjacência.
		vertices[i]['peso'] = 0
	else:
		vertices[i]['peso'] = None

	# Setando lista de adjacência...
	vertices[i]['lista_adjacencia'] = []

# Definindo o grafo:
grafo = Grafo(vertices, a, b)

# Setando as arestas...
for j in range(q):
	# Definindo cada aresta...
	pontoPartida, pontoChegada, distancia = map(int, input().split())
	# Para a entrada ser válida, os vértices precisam estar entre
	# 1 e n e serem diferentes um do outro.
	# Caso os vértices sejam iguais, a distancia será 0.
	if (pontoPartida != pontoChegada) and \
	(pontoPartida <= n and pontoPartida > 0) and \
	(pontoChegada > 0 and pontoChegada <= n):
		grafo.addAresta(pontoPartida, pontoChegada, distancia)

	elif pontoChegada == pontoPartida:
		grafo.addAresta(pontoPartida, pontoChegada, 0)

	# Adicionando o vértice b na lista de adjacência de a:
	grafo.get_lista_adjacencia_vertice(pontoPartida).append(pontoChegada)


print("Menor distância: %d" % grafo.dijkstra(a))
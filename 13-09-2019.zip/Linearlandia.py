from collections import defaultdict

class Grafo:
	def __init__(self):
		self._vertices = set()	# conjunto de nós
		self._arestas = defaultdict(set)	# conjunto de arestas
		self._distancias = {}	# distancia entre cidades

	def getCidades(cls):
		''' Retorna o conjunto de vértices'''
		return cls._vertices

	def getEstradas(cls):
		''' Retorna um dicionário de cada cidade com suas fronteiras'''
		return cls._arestas

	def getDistancias(cls):
		''' Retorna um dicionario com as arestas e distâncias '''
		return cls._distancias

	def addCidade(cls, cidade):
		''' Adiciona uma nova cidade ao grafo '''
		cls._vertices.add(cidade)

	def addEstrada(cls, inicio, destino, distancia):
		''' Adiciona uma aresta. '''
		cls._arestas[inicio].add(destino)	# Adicionando a fronteira ao ponto de inicio
		cls._arestas[destino].add(inicio)	# Adicionando a fronteira ao ponto de destino

		# Como a estrada é bidirecional, a distancia de A para B é a distancia de B para A...
		cls._distancias[(inicio, destino)] = cls._distancias[(destino, inicio)]= distancia


def encontra_caminhos(grafo, estado_atual, fim, caminho = [], caminhos = []):
	''' Função que procura caminho entre duas cidades '''

	# A cada iteração, o elemento é adicionado ao caminho
	caminho = caminho + [estado_atual]

	# Se o estado_atual for o final, encontramos um caminho...
	if estado_atual == fim:
		return caminho

	# Se ele está no caminho, não precisa mais ser verificado
	grafo.getCidades().remove(estado_atual)

	# Pegando os vizinhos, excluindo as cidades já verificadas...
	# Usando a operação de interseção entre conjuntos.
	vizinhos = grafo.getEstradas()[estado_atual] & grafo.getCidades()

	# Se houver vizinhos, será feita a verificação
	if vizinhos:
		for vizinho in vizinhos:
			novo_caminho = encontra_caminhos(grafo, vizinho, fim, caminho, caminhos)
			# Se for feita a pesquisa e tiver sido encontrado um caminho,
			# será feita a comparação para averiguar se é o melhor possível.
			if novo_caminho:
				if vizinho == fim:
					caminhos.append(novo_caminho)

		# Retornando os caminhos possíveis...
		return caminhos

def menor_caminho(grafo, caminhos_possiveis):
	''' Função que retorna a menor distância entre duas cidades.'''
	menor = 0

	# Vasculhando cada caminho encontrado
	for caminho in caminhos_possiveis:
		distancia_total = 0
		for i in range(1, len(caminho)):
			cidade_anterior = caminho[i-1]	# De onde veio...
			cidade_seguinte = caminho[i]	# Para onde vai...

			distancia_total += grafo.getDistancias()[(cidade_anterior, cidade_seguinte)]

		if menor == 0 or distancia_total < menor:
			# Se o caminho é não-nulo ou menor do que os outros já
			# vasculhados, significa que este caminho tem a menor distância.
			menor = distancia_total

	return menor

n, a, b = map(int, input().split())
# n é o número de cidades
# a é a cidade de inicio
# b é a cidade destino

if a == b:
	# Significa que não sairam de cidade, portanto a distância é 0.
	print(0)

else:
	# Criando um grafo.
	grafo = Grafo()

	# Definindo as arestas.
	for i in range(n-1):
		pontoA, pontoB, distancia = map(int, input().split())
		# pontoA e ponto B são os vértices da aresta
		# distancia é o comprimento da estrada que os ligam

		# Adicionando as cidades ao conjunto de cidades...
		grafo.addCidade(pontoA) ; grafo.addCidade(pontoB)

		# Adicionando uma estrada...
		grafo.addEstrada(pontoA, pontoB, distancia)

	# Vasculhar o gráfico para encontrar os caminhos possíveis...
	caminhos_encontrados = encontra_caminhos(grafo, a, b)
	# Dentre os caminhos encontrados, retorna o menor.
	print(menor_caminho(grafo, caminhos_encontrados))